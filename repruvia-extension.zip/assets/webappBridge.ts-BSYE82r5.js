(function(){const n=chrome.runtime.id;document.documentElement.dataset.repruviaExtensionId=n;const i=()=>{window.postMessage({source:"repruvia-extension",kind:"extension-id",id:n},"*")};i();window.addEventListener("message",e=>{e.source===window&&e.data?.source==="repruvia-webapp"&&e.data?.kind==="whois"&&i()});
})()
